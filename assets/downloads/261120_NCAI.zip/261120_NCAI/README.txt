﻿261120_NCAI  |  Unity 수업 실습 프로젝트

Unity Hub의 Add 메뉴에서 이 파일 옆의 Assets, Packages, ProjectSettings가 들어 있는 폴더를 선택하세요.
Unity 6000.4.0f1로 열어 패키지 복원과 컴파일이 끝나면 Assets/Scenes/TitleScene.unity를 열고 Play를 누르세요.
GameStart로 게임을 시작합니다. WASD 이동, 마우스 시점 회전, Space 점프, 왼쪽 클릭 발사, Esc 커서 해제.
처치당 10점이며 100점에서 클리어 화면을 표시합니다. 다시 시작하려면 Play를 종료하고 타이틀 씬에서 재생하세요.

수업 씬 두 개, C# 스크립트, UI 프리팹, 입력 및 URP 설정을 담은 편집용 사본입니다.
공개본의 타이틀 배경은 단색이며 모델은 기본 도형, 명중 효과는 짧은 파티클, 두 씬의 배경음은 합성 루프로 대체했습니다.
발사·피격 효과음은 수업 원본의 Dustyroom Casual Game Sounds (CC0) 두 파일을 사용합니다. Notices 폴더에서 배포 조건을 확인할 수 있습니다.
