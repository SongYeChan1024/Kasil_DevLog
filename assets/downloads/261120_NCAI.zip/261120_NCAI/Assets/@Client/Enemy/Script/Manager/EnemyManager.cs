using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    [SerializeField] private GameObject enemyPrefab = null;

    private SpawnPoint[] spawnPointArray = null;

    private List<Enemy> enemyList = null;

    private Action<int> onEnemyDie = null;

    private void Awake()
    {
        spawnPointArray = GetComponentsInChildren<SpawnPoint>();
        enemyList = new List<Enemy>();
    }

    public void Init(Player player, Action<int>onEnemyDie)
    {
        StartCoroutine (CoSpawnEnemies(player));
        this.onEnemyDie = onEnemyDie;
    }

    private IEnumerator CoSpawnEnemies(Player player)
    {
        while (true)
        {
            if (enemyList.Count < 5)
            {
                SpawnEnemy(player);
                yield return new WaitForSeconds(1f);
            }
            yield return null;
        }
    }

    private void SpawnEnemy(Player player)
    {
        // Enemy �� ��ȯ�Ϸ���
        // Prifab �� ��� �ϰ�
        // GameOnject �� ��ȯ�� ������
        // Enemy ������Ʈ�� ��������
        // Inin �Լ� ȣ������� ��

        int randomIndex = UnityEngine.Random.Range(0, spawnPointArray.Length);
        Vector3 spawnPosition = spawnPointArray[randomIndex].transform.position;
        Quaternion spawnRotation = spawnPointArray[randomIndex].transform.rotation;

        GameObject go = Instantiate(enemyPrefab, spawnPosition, spawnRotation);
        Enemy enemyComponent = go.GetComponent<Enemy>();
        if (enemyComponent != null)
        {
            enemyList.Add(enemyComponent);
            enemyComponent.Init(player, OnEnemyDie);
        }
    }

    private void OnEnemyDie(Enemy enemy, int score) // �Լ� å�� ������
    {
        RemoveEnemy(enemy);
        onEnemyDie?.Invoke(score);
    }

    private void RemoveEnemy(Enemy enemy)
    {
        enemyList.Remove(enemy);
    }

}
