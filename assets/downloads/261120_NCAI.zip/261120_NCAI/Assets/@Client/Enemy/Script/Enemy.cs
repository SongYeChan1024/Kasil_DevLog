using System;
using System.Collections;
using UnityEngine;

public class Enemy : MonoBehaviour, IDamageable
{
    // �������� ���� �� �ִ� �༮
    // ü��, �ִ� ü��
    // ������ �󸶳� ������ �ο�����

    [SerializeField] private float hp = 0f;
    private float maxHp = 100f;
    private int score = 10;

    [SerializeField] private float moveSpeed = 3f;

    private Player player = null;

    private Action<Enemy, int> onEnemyDie = null;

    private AudioSource source = null;
    private void Awake()
    {
        hp = maxHp;
        source = GetComponent<AudioSource>();
    }

    public void Init(Player player, Action<Enemy, int> onEnemyDie)
    {
        this.player = player;
        this.onEnemyDie = onEnemyDie;
        StartCoroutine(CoChasePlayer());
    }

    private IEnumerator CoChasePlayer()
    {
        while (true)
        {
            Vector3 direction = (player.transform.position - transform.position).normalized;

            float distance = (player.transform.position - transform.position).magnitude;

            if (distance >= 3f)
            {
                transform.position += direction * moveSpeed * Time.deltaTime;
            }
            else
            {
                player.TakeDamage(10f);
                yield return new WaitForSeconds(2f);
            }
                yield return null;
        }
    }

    //private void OnTriggerEnter(Collider other)
    //{
    //    Bullet bullet = other.GetComponent<Bullet>();
    //    if (bullet != null)
    //    {
    //        source.Play();
    //    }
    //}

    public void TakeDamage(float damage)
    {
        hp -= damage;

        source.Play();

        if (hp <= 0f)
        {
            Die();
        }
    }

    private void Die()
    {
        onEnemyDie?.Invoke(this, score);

        Destroy(gameObject);
    }
}
