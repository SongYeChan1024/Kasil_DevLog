using UnityEngine;
using MyManager;

public class Test : MonoBehaviour
{
    public void Start()
    {
        //GameManager.GetInstance().AddScore();
        GameManager.Instance.AddScore();
    }
}
