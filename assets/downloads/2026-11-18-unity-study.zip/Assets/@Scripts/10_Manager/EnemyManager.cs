using UnityEngine;

namespace MyManager
{
    public class EnemyManager : Singleton<EnemyManager>
    {

    }
}
