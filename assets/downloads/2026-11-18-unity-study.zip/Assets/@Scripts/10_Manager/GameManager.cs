using UnityEngine;
using UnityEngine.SceneManagement;

namespace MyManager
{
    public class GameManager : MonoBehaviour
    {
        // Manager
        // 점수를 관리하거나, 특정 오브젝트를 관리할 때
        // Manager 라는 객체를 사용함
        // 지금 보면, Scene1 에서 쌓았던 점수가
        // Scene2 에서는 초기화 되어 있는걸 볼 수 있음
        // Unity는 씬을 바꿀 때, 모든 오브젝트를 파괴하고
        // 새로 만들기 때문에 그럼

        // static
        // 일반 변수들은 게임이 돌아가고 있을 때
        // 각자 타이밍에 맞게 메모리에 올라감
        // static이 붙은 변수는 게임이 시작할 때,
        // 메모리 중에 Data 영역이 있는데,
        // 거기 생성이 됨.
        // 그리고 게임이 끝날 때 메모리에서 해제 됨
        private static GameManager instance = null;
        // 변수인데 함수처럼 쓸 수 있는게 있음
        // 프로퍼티(Property)
        public static GameManager Instance
        {
            get
            {
                if (instance == null)
                {
                    FindAnyObjectByType<GameManager>();
                    if (instance == null)
                    {
                        // GameManager를 만들어서 등록하면 됨
                        GameObject go = new GameObject(); // 게임오브젝트를 만들고
                        instance = go.AddComponent<GameManager>(); // 등록
                        go.name = "[Singleton] GameManager"; // 이름 설정

                        DontDestroyOnLoad(go); // 없어지지 않게 보호
                    }
                }
                return instance;
            }
        }

        // 그리고, 점수를 계산하는 매니저가 씬에
        // 여러개가 배치되어 있으면, 어떤 점수가 
        // 진짜인지 모르게 됨
        // 즉 씬에 메니저는 하나만 존재해야 함

        // 이러한 문제를 해결하기 위해서
        // 싱글턴(Singleton) 패턴 이라는 것 을 사용함


        // 싱글턴 패턴
        // 무조건 지워지지 않는 
        // 하나의 객체만 남기고 싶을 때 사용
        // 장점:
        // 사용성이 좋음
        // 무조건 객체가 하나인걸 보장할 수 있음
        // (싱글 스레드 에서만)
        // 단점:
        // static을 쓰기 때문에
        // 게임의 시작과 끝에서 오브젝트가 계속 살아있음
        // 그래서 남발하면 메모리를 많이 쓰게 됨
        // 데이터 오염이 쉬움

        private int score = 0;

        private void Awake()
        {
            if (instance == null || instance == this)
            {
            instance = this;
            DontDestroyOnLoad(gameObject);
            }
            else
            {
                Destroy(gameObject);
            }
        }
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                AddScore();
            }
            if (Input.GetKeyDown(KeyCode.Space))
            {
                SceneManager.LoadScene("GameScene");
            }
        }


        // 만약, 하이어라키에, GameManager가
        // 여러개 있으면, 그 중에 하나만 instance
        // 에 들어가긴 하는데,
        // 어떤놈이 들어가는지를 모름
        // 그래서, 게임 시작할 때 , GameManager를
        // 한개만 남게 만들거임
        //public static GameManager GetInstance() // 싱글턴 매니저 블러오기
        //{
        //    // 씬에 같은 게임매니저가
        //    // 여러개 있는 문제
        //    // 만약에 instance가 null 인 경우
        //    if (instance == null)
        //    {
        //        FindAnyObjectByType<GameManager>();
        //        if (instance == null)
        //        {
        //            // GameManager를 만들어서 등록하면 됨
        //            GameObject go = new GameObject(); // 게임오브젝트를 만들고
        //            instance = go.AddComponent<GameManager>(); // 등록
        //            go.name = "[Singleton] GameManager";

        //            DontDestroyOnLoad(go);
        //        }
        //    }
        //    return instance;
        //}

        public void AddScore()
        {
            ++score;
            Debug.Log(score);
        }
    }
}
