using UnityEngine;
using UnityEngine.Lumin;

namespace MyLifeCycle
{
    public class MyLifeCycle : MonoBehaviour
    {
        private Player player = null;
        private float lastFixedUpdateTime = 0f;
        private float lastUpdateTime = 0f;
        // 생명주기 (LifeCycle)
        // 순서 Reset - Awake - OnEnable - Start - FixedUpdate
        // - OnTriggerXXX - OnCollisionXXX - Update -
        // LateUpdate - OnDisable - OnDestroy -
        // OnDestroy - OnApplicationQuit 
        private void Reset() // 유니티 에디터에서 컴포넌트의 기본값과 참조를 설정할 때 쓰는 함수
        {
            Debug.Log("Reset 호출!");
            // 컴포넌트를 만들다 보면,
            // 컴포넌트의 초기값을 설정해야 할 때가 있음
            // Reset함수에서 초기값을 설정하고,
            // 컴포넌트를 게임오브젝트에 붙이거나,
            // 컴포넌트의 메뉴에서 Reset을 누르면
            // 이 함수가 실행이 됨
        }

        // 여기서부터
        private void Awake() // 게임이 시작될 때, 관여하는 생명주기 함수, 변수의 초기화 담당
        {
            // 게임 시작할 때, 한번 호출
            Debug.Log("Awake 호출!");
            player = new Player();
            
        }

        private void OnEnable() // 게임에서 어떤 오브젝트가 켜질 때 마다 호출되는 생명주기 함수
        {
            // 게임오브젝트가 켜질 때 호출
            // 게임이 시작되면, 유니티가
            // 하이어라키에 있는 모든 게임오브젝트를
            // 다시 만들게 되므로, 게임 시작할 때 도 호출됨
            Debug.Log("OnEnable 호출!");
        }

        private void Start()
        {
            // Awake 와 비슷함
            // 게임이 시작되면 딱 한번 호출됨
            // 무조건 Awake 다음 순서로 호출됨
            Debug.Log("Start 호출!");
            player.SetAge(10);
        }

        private void FixedUpdate() 
        {
            // 매 프레임 호출되는 함수
            // 0.02초(고정) 마다 호출
            // 물리처리나 일정한 판정이 필요할 때 사용
            Debug.Log("FixedUpdate 호출!");
            
            // 지금 시간 저장
            //float current = Time.time;
            //float interval = lastFixedUpdateTime - current;
            //lastFixedUpdateTime = current;
            //Debug.Log("FixedUpdateInterval: " + interval.ToString("F4"));
            
        }

        private void Update() 
        {
            // 매 프레임 호출되는 함수,
            // PC의 성능에 따라 호출되는 속도가 다름
            Debug.Log("Update 호출!");

            float current = Time.time;
            float interval = lastUpdateTime - current;
            lastUpdateTime = current;
            Debug.Log("UpdateInterval: " + interval.ToString("F4"));
        }

        private void LateUpdate()
        {
            // Update 보다 한 프레임 늦게 동작하는 함수
            // 플레이어가 움직인 후, 따라다니는 카메라가 있음
            // 그런 카메라 같은 거 로직 작성할 때 , LateUpdate 를 사용함
            Debug.Log("LateUpdate 호출!");
        }

        private void OnDisable()
        {
            // OnEnable과 반대로 오브젝트가 켜져 있다가 꺼질 때 호출됨
            Debug.Log("OnDisable 호출!");
        }

        private void OnDestroy()
        {
            // 오브젝트가 파괴될 때 호출 됨
            // 오브젝트가 파괴될 때, 
            // 유니티는 오브젝트를 먼저 disable 시키고
            // destroy 시킴.
            // 그래서 오브젝트를 파괴시키면
            // OnDisable -> OnDestroy 순서로 호출이 됨
            Debug.Log("OnDestroy 호출!");
        }



        public class Player
        {
            private int age = 0;

            public void SetAge(int age)
            {
                this.age = age;
            }
        }
    }

}