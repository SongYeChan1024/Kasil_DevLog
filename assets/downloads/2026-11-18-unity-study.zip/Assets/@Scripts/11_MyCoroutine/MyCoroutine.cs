using System.Collections;
using UnityEngine;

namespace MyCoroutine
{ 
    public class MyCoroutine : MonoBehaviour
    {
        // Corouttine 코루틴

        // 동기식 방식 synchrounous
        // 비동기식 방식 asynchrounous

        // 싱글스레드 환경에서
        // 비동기로 작업을 처리할 수 있게 해주는 문법

        // StartCoroutine()

        // Coroutine
        // 비동기 작업을 할 수 있게 해주는 문법
        // yield return 을 만나기 전까지의 코드를
        // 하나의 작업 단위로 만듦 (IEnumerator)
        // 코루틴을 작업단위를 하나씩 순서대로 실행시켜
        // 주는 상태 머신이라과 생각하면 됨

        private WaitForSeconds coTime;

        // Caching 캐싱
        private WaitForFixedUpdate waitForFixedUpdate;
        private void Awake()
        {
           coTime = new WaitForSeconds(5.0f);
           waitForFixedUpdate = new WaitForFixedUpdate();
        }
        private void Start()
        {
            //StartCoroutine(CoSomeCoroutine());
            StartCoroutine(CoCleanWindow());
            StartCoroutine(CoCleanFloor());


        }

        private IEnumerator CoCleanWindow()
        {
            for (int i = 0; i < 10; ++i)
            {
                Debug.Log("철수가 창문을 닦는 중..");
                yield return null;
            }
        }

        private IEnumerator CoCleanFloor()
        {
            for (int i = 0; i < 10; ++i)
            {
                Debug.Log("영희가 바닥을 쓰는중..");
                yield return null;
            }
        }
        private IEnumerator CoSomeCoroutine()
        {
            // yield return 을 만나기 전 까지
            // 어떤 코드가 있을껀데
            // 그 코드를 하나의 작업 단위로 봄
            // 그래서 그 코드는 yield return 을
            // 만나기 전 까지 작업을 수행함
            while (true)
            {
                //Debug.Log("뭔데 뭘 할껀데 뭘 하고 싶은건데 딱 말해 나한테");
                //yield return coTime;
                Debug.Log("뭔데 뭘 할껀데 뭘 하고 싶은건데 딱 말해 나한테");
                yield return new WaitForFixedUpdate();
            }
                //Debug.Log("뭔데 뭐냐고 왜 대답을 안하는데 빨리 말해달라니까 뭘 하고 싶냐고");
                //yield return coTime;
        }
    }
}
