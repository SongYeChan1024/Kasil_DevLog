using UnityEngine;

namespace MyPrefab
{
    public class MyPrefab : MonoBehaviour
    {
        // Prefab

        // Item을 소환할건데
        // A아이템을 2개 소환한다고 생각해 봄

        // 1. 어떤 오브제그를 소환할 것인가?
        [SerializeField] private GameObject item = null;

        private void Update()
        {
            if (Input.GetKeyUp(KeyCode.Space))
            {
                // 아이템을 하나 소환할거임
                // Isntantiate
                // (소환할오브젝트, 위치, 회전값)
                //GameObject go = Instantiate(item, new Vector3 (2f, 3f, -1f ), Quaternion.identity);

                // Random.Range(최소, 최대)
                // Space를 눌렀을 때, 랜덤한 위치에 소환할거고
                // 아이템 색상을 랜덤으로 조절해봄
                float randomX = Random.Range(-5f, 5f);
                float randomY = Random.Range(-5f, 5f);
                float randomZ = Random.Range(-5f, 5f);

                GameObject go = Instantiate(item,
                    new Vector3(randomX, randomY, randomZ) , 
                    Quaternion.identity); // 스페이스를 눌렀을 때 item 이라는 오브젝트를 랜덤한 위치에 생성

                MeshRenderer renderer = go.GetComponent<MeshRenderer>(); // 색상을 조정하기 위해서 매쉬랜더러 확보
                if (renderer != null)
                {
                    renderer.material.color = new Color(
                        Random.Range(0f, 1f), 
                        Random.Range(0f, 1f), 
                        Random.Range(0f, 1f)); // 랜덤값 적용
                }
            }
        }
    }
}
