using UnityEngine;

namespace MyRigidbody
{

    public class MyRigidbody : MonoBehaviour
    {

    }   
}
