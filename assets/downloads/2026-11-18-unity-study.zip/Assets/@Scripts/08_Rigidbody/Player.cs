using UnityEngine;
using UnityEngine.Rendering;

namespace MyRigidbody
{
    public class Player : MonoBehaviour
    {
        // Rigidbody: 강체물리
        // Transform 기반으로 움직임을 처리하면
        // Player의 이동속도가 빨라질 때, 
        // 벽을 뚫어버리는 문제가 발생할 수 있음
        // 그래서 보통 Rigidbody로 움직임을 구현함

        // 플레이어가 땅에 붙어있는 상태를 체크해보자
        // 1. 충돌처리로 구현 할 수 있음 -> bool수가 필수적
        // 으로 생기기 때문에 권장 x
        // 2. Raycast 방식
        // 플레이어의 발 아래쪽으로 레이저 같은걸 쏴서 
        // 땅바닥이랑 레이저랑 부딪히는지 체크할거임
        // Phisics.Raycast(내위치, 방향, 맞은녀석, 레이저 길이)

        private Rigidbody rb = null;

        [SerializeField] float moveSpeed = 0f;

        [SerializeField] float jumpPower = 0f;

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
        }

        // 플레이어를 Rigidbody를 활용해서
        // WASD로 이동시키고
        // Space를 누르면 Jump 할 수 있도록 만들어 봄

        private void Update()
        {
            Move();

            Jump();
            Debug.DrawRay(transform.position, -transform.up * 1.1f, Color.red);

        }

        private void Move()
        {
            // 물리처리에서
            // 플레이어는 일정한 속도를 가지고 있음
            // 3차원에서 속도도 3차원 벡터로 표현할 수 있음
            // 키 입력에 따라서 어디로, 얼마나 움직여야 하는지
            // Vector를 구해서 Rigidbody의 속력에다가
            // 대입해주면 됨

            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");

            // (0, 0, 1)
            // (1, 0, 0)
            Vector3 direction = transform.forward * vertical + transform.right * horizontal; // 이동처리

            Vector3 normalizedDirection = direction.normalized; // 이동처리 정규화

            Vector3 velocity = new Vector3(normalizedDirection.x * 
                moveSpeed, rb.linearVelocity.y, 
                normalizedDirection.z * moveSpeed); // 이동속도 처리

            rb.linearVelocity = velocity; // 이동속도 적용

        }

        private void Jump()
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                // 점프기능 구현할거임
                // 점프하기 직전에, y축의 속도를 순간적으로 0으로 만듦
                // Rigidbody.Addforce()

                if (Physics.Raycast(transform.position, 
                    -transform.up, 
                    out RaycastHit hit, 1.1f)) // 캐릭터의 중앙에서 레이가 뻗어나오기 때문에 1.1로 길이를 맞추고 판정 확인
                {
                rb.linearVelocity = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z); // 점프 직전 y축 속도 초기화

                rb.AddForce(new Vector3(0f, 1f, 0f) * jumpPower, ForceMode.Impulse); // 점프 속도와 방향, 힘의 종류 적용
                }
            }
        }
    }   
}
