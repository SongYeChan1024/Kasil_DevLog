using UnityEngine;

namespace MyVector
{

    public class Player : MonoBehaviour
    {
        // 게임이 시작됐을 때,
        // ->Start에서 작업 하면 되겠네

        // 지금 Player는 0,0,0에 위치하고 있는데 
        // Transform 이라는 컴포넌트를 가져와야 함

        // 이 Player를 10,5,-1로 위치하게 해보자
        // Position 이라는 변수값을 바꿔야 함
        // -> 3가지의 수를 넣어야 하는데 3차원 벡터로 넣자

        private void Start () 
        {
            // Transform tr = GetComponent<Transform>();
            // MocoBehaviour를 상속받으면
            // Transform 이라는 컴포넌트는 엄청 자주 쓰기 때문에
            // 유니티가 transform 이라는 변수를 만들고
            // 게임 시작함과 동시게 Transform을 자동으로 가져오게 
            // 만들어 뒀음
            // 그래서 Transform을 조작 할 때는 GetComponent 하지 않고
            // transform 이라는 변수를 바로 사용하면 됨
            transform.position = new Vector3(10f, 5f, -1f);
        }
    }

}