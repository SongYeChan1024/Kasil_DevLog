using MyVector;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // Enemy 라는 녀석이 Player를 졸졸 따라다닐거임

    // 필요한 정보등
    // 1. Enemy 본인의 위치
    // 2. Player의 위치
    [SerializeField] private Player player = null;
    // 3. 얼마나 빠르게 이동할건지 (이동속도)
    private float moveSpeed = 5f;

    // 게으른 초기화 (Lazy Initialize)
    // 의존성 주입 (Dependency Injection) DI
    public void Init(Player player, float moveSpeed)
    {
        this.player = player;
        this.moveSpeed = moveSpeed;
    }

    public void SetPlayer(Player player)
    {
        this.player = player;
    }
    // Update에서 작업할거임
    private void Update()
    {

        // 1. Player를 바라보는 벡터를 구해야 함 
        Vector3 destination = player.transform.position - transform.position;

        float distance = destination.magnitude;
        Debug.Log(distance);

        Vector3 normalizedVector = destination.normalized;

        if (distance >= 3f)
        {
        transform.position += normalizedVector * moveSpeed * Time.deltaTime;
        }
    }
    
}
