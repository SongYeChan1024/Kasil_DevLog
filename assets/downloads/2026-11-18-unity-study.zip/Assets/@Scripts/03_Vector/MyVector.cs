using UnityEngine;

namespace MyVector
{

    public class MyVector : MonoBehaviour
    {
        private Player player = null;
        private Enemy enemy = null;
        // 벡터 (Vector)
        // 힘과 방향을 가진 수
        // 수의 집합
        // (1,2) -> 2차원 벡터
        // (3,4,5) -> 3차원 벡터

        // 벡터의 연산
        // 벡터의 더하기
        // x축만 있는 좌표공간에서
        // 어느 한점을 찍었을 때, 그 위치는
        // x축 하나로 표현할 수 있음
        // 즉, 수가 하나이므로 1차원 벡터임
        // 2라는 벡터와 3이라는 벡터를 서로 더하면
        // 5라는 벡터가 됨
        // 즉, 벡터의 더하기는 같은 성분끼리 더하는
        // 것이라고 생각하면 됨
        // 또한, 여기서 알 수 있는것은 힘과 방향만
        // 같으면 같은 벡터로 취급한다는 것임
        // 구조체 (struct)

        private void Awake()
        {
            player = GetComponentInChildren<Player>();
            enemy = GetComponentInChildren<Enemy>();
        }
        private void Start()
        {
            enemy.SetPlayer(player);

            // x:2, y:2, z:0
            Vector3 vector1 = new Vector3(2f, 2f, 0f);
            // x:2, y:0, z:0
            Vector3 vector2 = new Vector3(2f, 0f, 0f);
            Vector3 vector3 = vector1 + vector2;
            Debug.Log(vector3);

            // 벡터의 뺄셈
            // 같은 성분끼리 빼기를 하면 됨
            // 만약, A라는 벡터와 B라는 벡터가 있을 때
            // A-B를 하면, 같은 성분끼ㅏ리 뺀 값이 나오고,
            // 그 벡터의 방향은 B가 A를 바라보는 방향으로 
            // 설정, 진행이 됨
            Vector3 vector4 = new Vector3(5f, 3f, 0f);
            Vector3 vector5 = new Vector3(1f, 2f, 1f);
            Vector3 vector6 = vector4 - vector5;
            Debug.Log(vector6);

            // 벡터의 힘
            // (3f, 4f, 0f)
            // 스칼라 라고 부름
            // 스칼라를 구하는 방식
            // 각 성분을 제곱해서 더하고, 제곱근을 씌워주면 됨
            Vector3 vector = new Vector3(3f, 4f, 0f);
            // 프로퍼티 (Property)
            // 변수를 함수처럼 사용하는 문법
            float scalar1 = vector.magnitude;
            Debug.Log(scalar1);

            // 벡터의 정규화
            Vector3 vector7 = new Vector3(1f, 0f, 0f);
            Vector3 vector8 = new Vector3(0f, 1f, 0f);
            Vector3 vector9 = vector7 + vector8;
            float sclar2 = vector9.magnitude;
            Debug.Log(sclar2); // 1.414
            // 어떤 벡터를 향은 그대로 놔두고,
            // 힘은 1로 만드는 과정을 정규화 라고 함
            Vector3 normalizedVector = vector9.normalized;
            Debug.Log(normalizedVector);
            Debug.Log(normalizedVector.magnitude);

        }
    }

}