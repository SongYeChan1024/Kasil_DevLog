using UnityEngine;

namespace MyComponentScan
{
    public class ComponentScan : MonoBehaviour
    {
        // 변수를 만들어서 어떤 큐브인지를 저장 해둬야 함
        // 멤버변수는 무조건 private 이 좋음
        // private 하면 inspector에서
        // 값을 할당할 수 없음
        // 그래서 SerializeField(직렬화) 라는
        // '어트리뷰트' 를 사용함
        [SerializeField] private GameObject cubeObject123 = null;
        // 컴포넌트 가져오기

        // 월드에, Cube가 하나 있음
        // 이 큐브를 z축 방향으로 서서히 움직이게
        // 하고 싶음

        // 1. 움직이고 싶은 Cube를 먼저 찾고
        // 2. Cube를 선택한 다음에
        // 3. Cube에 있는 Tranform 컴포넌트를 찾아서
        // -> 오브젝트 안에 특정 컴포넌트를 가져오는 함수를 알아볼 것
        // GetComponent<T>()
        // 4. z축에 있는 값을 바꿨음

        private void Awake()
        {
            // GetComponent를 사용해서
            // 컴포넌트를 가져올꺼임
            Transform tr = cubeObject123.GetComponent<Transform>();
            Debug.Log(tr.position);
            Debug.Log(tr.name);

            Transform tr1 = GetComponent<Transform>();
            Debug.Log(tr1.position);
            Debug.Log(tr1.name);

            // 나(ComponentScan)의 자식으로 
            // Player가 달려있는데
            // 자식으로 있는 Player의 Transform
            // 을 가져오고 싶음
            // GetComponentInChildren<T>()
            Transform playerTr = GetComponentInChildren<Transform>();
            Debug.Log(playerTr.position);
            Debug.Log(playerTr.name);

            // GetComponentInChildren 을 하면
            // 본인한테 Tranform 컴포넌트가 있으면
            // 본인의 Transform 컴포넌트를 가져오는 문제가
            // 있음

            // -> 나한테는 없지만 자식한테만 있는
            // 컴포넌트를 만들어서 그것을 기준으로 찾아옴
            // -> 즉, Player 오브젝트에 
            // ComponentScan 오브젝트에는 없는 Player
            // 컴포넌트를 만들어서 달아주고, 그거ㅏㅅ을
            // 기준으로 찾아옴
            Player playerComponent = GetComponentInChildren<Player>();
            Transform playerTr1 = playerComponent.GetComponent<Transform>();
            Debug.Log(playerTr1.position);
            Debug.Log(playerTr1.name);

            // Player가 6명이 생겼고
            // 6명의 각각 Transform을 가져오고 싶음
            // GetComponentsInChildren
            // 배열 Array
            Transform[] playerArray = GetComponentsInChildren<Transform>();

            for (int i = 0; i < playerArray.Length; ++i)
            { 
                Transform playerTr2 = playerArray[i].GetComponent<Transform>();
                Debug.Log(playerTr2.position);
                Debug.Log(playerTr2.name);
            }
        }
    }
    // FindFirstObjectByType<T>()
    // FindAnyObjectByType<T>()
    // Find(오브젝트 이름)
    // 문자열 비교 성능....좀..
    // FindGameObjectWithTag(오브젝트의 태그명)
    // FindComponentInParent()
    // 이런 것들도 있긴 한데 안씀, 안쓰는게 더 좋음

    // Member Initializer
    // 생성자, 종료자
    // Log 붙이고
    // 어떤거는 Member Initializer
    // 어떤거는 Awake
    // 왠만하면 쓰지말자? Member Initializer은 성능이 구리다
}