using UnityEngine;

namespace MyComponentScan
{

    public class Player : MonoBehaviour
    {
        public void Describe()
        {
            Debug.Log("저는 Player 입니다!");
        }
    }
}
