using System.Runtime.CompilerServices;
using UnityEngine;

namespace MyCoordinateSystem
{

    public class Parent : MonoBehaviour
    {
        private void Update()
        {

        }
    }
}
