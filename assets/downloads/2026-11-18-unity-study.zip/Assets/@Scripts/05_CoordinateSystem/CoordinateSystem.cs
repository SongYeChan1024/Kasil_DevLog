using UnityEngine;

namespace MyCoordinateSystem
{
    public class CoordinateSystem : MonoBehaviour
    {
        // 좌표계(CoordinateSystem)
        // Global 좌표
        // 특정 객체가 어떤 행동을 해도
        // 동서남북 처럼 딱 정해져 있는
        // 좌표를 말함
        // transform.position -> Global 좌표

        // Local 좌표
        // 부모가 좌표계를 Glabal 좌표처럼 따라가는
        // 좌표를 말함
        // transform.localPosition -> Local 좌표
    }
}
