using UnityEngine;

namespace MyCoordinateSystem
{

    public class Child : MonoBehaviour
    {
        private void Update()
        {
            // Global 좌표 기준으로 z축 방향을 옮기니까:
            // 로컬 좌표가 틀어져 있어도 그로벌의 z축으로 
            //transform.position += new Vector3(0f, 0f, 1f) * Time.deltaTime;

            // Local 좌표
            // 부모의 좌표가
            // Global 좌표처럼 인식 됨
            //transform.localPosition += new Vector3(0f, 0f, 1f) * Time.deltaTime;

            // Child를 Global 좌표 기준으로 
            // 좌우로 움직이게 하고 싶음
            // z축 방향으로 회전시키면 될 듯
            transform.rotation *= Quaternion.Euler(new Vector3(0f, 0f, 1f)* Time.deltaTime);
        }
    }
}
