using UnityEngine;

namespace MyInputSystem
{

    public class Player : MonoBehaviour
    {
        // 1. WASD 입력을 받아서 압뒤좌우로 움직이는 기능
        // 1.1 키보드 입력만을 사용해서 움직임
        // 1.2 GetAxis를 사용해서 움직임
        // 2. 마우스 입력을 받아서, 플레이어의 회전값 조정

        [SerializeField] private float moveSpeed = 5f;

        [SerializeField]private float currentPitch = 0f;

        private Camera mainCamera = null;

        private void Awake()
        {
            mainCamera = GetComponentInChildren<Camera>();
        }
        private void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                LockCursor();
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                UnlockCursor();
            }
            //MoveWithKey();
            //MoveWithAxis();
            MoveWithAxisRaw();
            Rotate();
        }

        private void MoveWithKey()
        {
            // 만약에, W입력을 받았을 때
            // 플레이어의 Z축 방향으로 
            // 일정 값만큼 더해주면 됨
            // Vector 값을 더해줄거임

            // Vector3 direction = new Vector3(0f, 0f, 0f);
            Vector3 direction = Vector3.zero;

            if (Input.GetKey(KeyCode.W))
            {
                direction += transform.forward;
            }

            if (Input.GetKey(KeyCode.S))
            {
                direction -= transform.forward;
            }

            if (Input.GetKey(KeyCode.D))
            {
                direction += transform.right;
            }

            if (Input.GetKey(KeyCode.A)) 
            {
                direction -= transform.right;
            }
            Vector3 normalizedDirection = direction.normalized;
            transform.position += normalizedDirection * Time.deltaTime * moveSpeed;
        }

        private void MoveWithAxis()
        {
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");

            Vector3 direction = new Vector3(horizontal, 0f, vertical);

            Vector3 normalizedDirection = direction.normalized;

            Vector3 moveDirection = transform.TransformDirection(normalizedDirection);

            transform.position += moveDirection * Time.deltaTime * moveSpeed;
        }

        private void MoveWithAxisRaw()
        {
            float horizontalRaw = Input.GetAxisRaw("Horizontal");
            float verticalRaw = Input.GetAxisRaw("Vertical");

            Vector3 direction = new Vector3(horizontalRaw, 0f, verticalRaw);

            Vector3 normalizedDirection = direction.normalized;

            Vector3 moveDirection = transform.TransformDirection(normalizedDirection);

            transform.position += moveDirection * Time.deltaTime * moveSpeed;
        }

        private void Rotate()
        {
            // 나의 지금 회전값을 저장할 변수
            // 마우스의 움직임을 받을 로직이 필요함
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = Input.GetAxis("Mouse Y");

            float sensitivity = 2f;

            currentPitch -= mouseY * sensitivity;
            currentPitch = Mathf.Clamp(currentPitch, -90f, 90f);
            mainCamera.transform.localEulerAngles = new Vector3(currentPitch, 0f, 0f);

            float playerRotation = mouseX * sensitivity;
            transform.Rotate(0f, playerRotation, 0f);
        }

        private void LockCursor()
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        private void UnlockCursor()
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}
