using UnityEngine;

namespace MyInputSystem
{
    // InputSystem(Old)
    // Update에서 매 프레임 압력을 감지하는 방식
    // 구형하기는 쉽지만, 성능상 별로 안좋음
    // 또한, 다중 디바이스 대응이 어려움
    // (VR, PC , Mobile 등 따로따로 입력 매핑해야 함)

    // InputSystem(New)
    // 키가 눌러졌을 때 딱 한번만 정의 된 행동이 실행되는
    // 방식(이벤트 기반 입력 감지)
    // 다중 디바이스 매핑이 편리함
    // 단점으로는 초반 학습에 비용이 있음
    public class MyInputSystem : MonoBehaviour
    {
        private void Update()
        {
            // 만약에, 매프레임 검사를 했더니
            // 특정 프레임에, 특정키가 눌러졌으면
            // 어떤 행동을 해라

            // Z키를 한번 눌렀을 때 발동
            if (Input.GetKeyDown(KeyCode.Z))
            {
                Debug.Log("Z키 눌러짐");
            }

            // 특정키를 누르고 있는 동안
            // 계속 발동
            if (Input.GetKey(KeyCode.X))
            {
                Debug.Log("X키 눌러짐");
            }

            // 특정키를 누르고 있다가 뗄 때
            if (Input.GetKeyUp(KeyCode.C))
            {
                Debug.Log("C키 떼짐");
            }

            // 마우스 입력
            // GetMouseButtonDown
            // GetMouseButton
            // GetMouseButtonUp
            // 0: 마우스 좌클릭
            // 1: 마우스 우클릭
            // 2: 마우스 휠클릭

            if (Input.GetMouseButtonDown(0))
            {
                Debug.Log("마우스 좌클릭 됨");
            }
            if (Input.GetMouseButton(1))
            {
                Debug.Log("마우스 우클릭 됨");
            }
            if (Input.GetMouseButtonUp(2))
            {
                Debug.Log("마우스 휠 클릭 됨");
            }

            // Axis
            // 마우스의 움직임에 따라서
            // 값을 받을 수 있는 기능

            //// 마우스의 좌우 움직임을 가져옴
            //float mouseX = Input.GetAxis("Mouse X");
            //// 마우스의 상하 움직임 가져옴
            //float mouseY = Input.GetAxis("Mouse Y");
            //// 마우스의 휠이 움직이는 값을 가져옴
            //float mouseScroll = Input.GetAxis("Mouse ScrollWheel");
            //Debug.Log($"Mouse X: {mouseX} " + 
            //    $"Mouse Y: {mouseY}" + 
            //    $"Mouse Scroll: {mouseScroll}");

            //// Raw: 더 빠르게 값을 바꿀 때 사용
            //// 마우스의 좌우 움직임을 가져옴
            //float mouseXRaw = Input.GetAxisRaw("Mouse X");
            //// 마우스의 상하 움직임 가져옴
            //float mouseYRaw = Input.GetAxisRaw("Mouse Y");
            //// 마우스의 휠이 움직이는 값을 가져옴
            //float mouseScrollRaw = Input.GetAxisRaw("Mouse ScrollWheel");
            //Debug.Log($"Mouse X: {mouseXRaw} " +
            //    $"Mouse Y: {mouseYRaw}" +
            //    $"Mouse Scroll: {mouseScrollRaw}");

            // 키보드의 입력 상태를 받아봄
            // W를 눌렀을 때, 플레이어가 얼마만큼 빠르게 
            // 이동해야 하는지
            // -> 이 값을 정의할 때 사용함

            // -1 ~ 1 까지의 값만 가짐

            //float keyboardX = Input.GetAxis("Horizontal");
            //float keyboartY = Input.GetAxis("Vertical");
            //Debug.Log($"Horizontal: {keyboardX}" + $"Vertical: {keyboartY}");

            float keyboardXRaw = Input.GetAxisRaw("Horizontal");
            float keyboartYRaw = Input.GetAxisRaw("Vertical");
            Debug.Log($"Horizontal: {keyboardXRaw}" + $"Vertical: {keyboartYRaw}");
        }
    }
}   
