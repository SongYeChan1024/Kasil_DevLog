using UnityEngine;

namespace MyQuaternion
{

    public class MyQuaternion : MonoBehaviour
    {
        // 쿼터니언(Quaternion)
        private void Start()
        {
            // transform.rotation = new Vector3(90f, 90f, 0f);
            // Unity에서 Transform 컴포넌트 안에 있는
            // Rotation 이라는 속성을 보면
            // Position과 같이, 값이 3개가 들어가는 것을 
            // 볼 수 있음
            // 그래서 Position 과 같애 Rotation에
            // Vector3를 넣어보려고 하니까, 안들어감

            // 짐벌락
            // 3차원 세계에서 축이 3개가 있는데
            // 그 축마다 회전을 시켜야 함
            // 근데, Vector 형태로 회전을 시키다 보니까
            // 축이 하나로 겹쳐지는 상황이 나옴
            // 3축에서 2축이 되는거임
            // 이러한 현상을 짐벌락 이라고 함

            // y-x-z 축을 만들어서
            // 회전을 시켜 보니까 , x를 90도 만큼 회전하니
            // z축과 y축이 겹쳐버리는 문제가 발생했음
            // 이렇게 되면, 원래 z축의 회전이 사라지고 
            // z축과 y축이 병합이 되너 z축으로는 회전할 수 
            // 없게 되어버림
            // 이러한 현상을 짐벌락이라고 하고,
            // 짐벌락을 해결하기 위해서, 유니티는 가상의
            // w축을 만들어서, 총 4출으로 회전을 관리함
            // 4축 회전 시스템을 Quaternion 이라고 함

            //Quaternion rotation1 = Quaternion.Euler(new Vector3(0f, 90f, 0f));
            //transform.rotation = rotation1;

            //// Quaternion 의 더하기 빼기
            //// * (연산자 오버로딩)
            //// 곱하기로 구현
            //Quaternion rotation2 = Quaternion.Euler(new Vector3(90f, 0f, 0f));
            //Quaternion rotation3 = Quaternion.Euler(new Vector3(0f, 0f, 90f));
            //Quaternion rotation4 = rotation2 * rotation3;
            //Debug.Log(rotation4);
            //transform.rotation = rotation4;
        }
    }

}