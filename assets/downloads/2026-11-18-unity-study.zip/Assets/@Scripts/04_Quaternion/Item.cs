using UnityEngine;

namespace MyQuaternion
{

    public class Item : MonoBehaviour
    {
        [SerializeField]
        private float rotationSpeed = 0f;
        // 얼마만큼 빠르게 회전 할 것인가?
        // 무슨 축 기준으로 회전 할 것인가?
        private void Update()
        {
            transform.rotation *= Quaternion.Euler(new Vector3(0f, rotationSpeed , 0f) * Time.deltaTime);
        }
    }

}