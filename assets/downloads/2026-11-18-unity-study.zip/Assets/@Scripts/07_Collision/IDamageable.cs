using UnityEngine;

namespace MyCollision
{
    public interface IDamageable
    {
        public void OnDamage(float damage);
    }
}
