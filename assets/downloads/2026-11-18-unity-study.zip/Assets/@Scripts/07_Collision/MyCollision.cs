using UnityEngine;

namespace MyCollision
{
    public class MyCollision : MonoBehaviour
    {
        // 충돌처리 (Collision)

        // 강성체끼리 부딪혀서 서로 튕겨나는 상황
        // Collision
        // 강성체끼리 부딪혀도, 충돌만 체크하고
        // 튕겨나가지는 않는 상황
        // Trigger

        // Collider라는 컴포넌트를 붙여서 구현
        // Rigidbody라는 물리처리 컴포넌트가 붙어 있어야 함

        // 충돌 상황
        // 부딪혔을 때
        // 부딪혔다가 떨어졌을 때
        // 부딪히고 있을 때

        // OnCollisionXXX
        // OnTriggerXXX

        // Collision
        private void OnCollisionEnter(Collision collision)
        {
            //Debug.Log("충돌 처리 됨");
        }
    }
}
