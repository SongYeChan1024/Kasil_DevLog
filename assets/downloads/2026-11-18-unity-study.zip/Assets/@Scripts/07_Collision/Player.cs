using System.Runtime.CompilerServices;
using UnityEngine;

namespace MyCollision
{

    public class Player : MonoBehaviour
    {
        private float playerDamage = 10f;
        private void OnCollisionEnter(Collision collision)
        {
            // Collision
            // 충돌한 물체의 정보를 가지고 있는 클래스
            //Debug.Log("물체 충돌 함: "+ collision.gameObject.name);

            //if (collision.gameObject.name == "Enemy")
            //{
            //    Debug.Log("Enemy 한테 데미지 줌");
            //}

            // Tag 기준으로 구분
            //if (collision.gameObject.CompareTag("Enemy"))
            //{
            //    Debug.Log("Enemy 한테 데미지 줌");
            //}
            
            //Enemy enemy = collision.gameObject.GetComponent<Enemy>();
            //if ( enemy != null )
            //{
            //    Debug.Log("Enemy랑 충돌함");
            //    enemy.GetDamage(playerDamage);
            //}

            // 인터페이스
            // 클래스랑 똑같은데, 
            // 정의가 없음
            // 그냥 그 자식 클래스의 틀을 정의하는 문법
            IDamageable damageableObject = collision.gameObject.GetComponent<IDamageable>();

            // Null Conditional 연산자
            // ?
            damageableObject?.OnDamage(playerDamage);
            // if문과 똑같은 작용을 함

            //if (damageableObject != null)
            //{
            //    damageableObject.OnDamage(playerDamage * 2);
            //}
        }

        private void OnCollisionExit(Collision collision)
        {
            IDamageable damageableObject = collision.gameObject.GetComponent<IDamageable>();
            if (damageableObject != null)
            {
                Debug.Log("OnCollisionExit");
            }
        }

        private void OnCollisionStay(Collision collision)
        {
            IDamageable damageableObject = collision.gameObject.GetComponent<IDamageable>();
            if (damageableObject != null)
            {
                Debug.Log("OnCollisionStay");
            }
        }

        // Trigger 체크는
        // 충돌하는 2개의 물체 중에서 
        // 하나만 isTrigger 체크가 되어 있으면
        // Trigger 체크를 할 수 있음
        private void OnTriggerEnter(Collider other)
        {
            Debug.Log("OnTriggerEnter");
        }
    }
}
