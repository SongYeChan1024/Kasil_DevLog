using UnityEngine;

namespace MyCollision
{
    public class Enemy : MonoBehaviour, IDamageable
    {
        private float hp = 100f;

        public void GetDamage(float damage)
        {
            hp -= damage;
            Debug.Log(" Enemy 피격 받음: "+ hp);
        }

        public void OnDamage(float damage)
        {
            Debug.Log("인터페이스 안의 OnDamage함수");
            hp -= damage;
        }
    }
}
